const users = [{
		fname: "Harkirat",
		age: 21
	}, {
		name: "raman",
		age: 22
	}
]

const user1 = users[0] ;
const user1Name = users[0].fname;
const user1Age = users[0].age;

console.log(user1);
console.log(user1Name);
console.log(user1Age);