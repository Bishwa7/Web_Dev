
function canVote(age)
{
    if(age>=18)
    {
        return true;
    }
    else{
        return false;
    }
}

let age = 17;

let ans = canVote(age);

console.log(ans);